package com.akash.contactspro.di.contactsList

import javax.inject.Scope

@MustBeDocumented
@Scope
@Retention(AnnotationRetention.RUNTIME)
annotation class ContactsListScope