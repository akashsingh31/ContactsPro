package com.akash.contactspro.di.contactDetails

import javax.inject.Scope

@MustBeDocumented
@Scope
@Retention(AnnotationRetention.RUNTIME)
annotation class ContactDetailsScope