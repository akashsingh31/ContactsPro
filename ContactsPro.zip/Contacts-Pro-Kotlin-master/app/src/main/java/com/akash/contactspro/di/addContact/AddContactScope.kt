package com.akash.contactspro.di.addContact

import javax.inject.Scope

@MustBeDocumented
@Scope
@Retention(AnnotationRetention.RUNTIME)
annotation class AddContactScope